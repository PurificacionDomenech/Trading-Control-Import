# TradingControl
App parra registro y control de tu trading
